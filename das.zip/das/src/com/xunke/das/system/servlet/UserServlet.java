package com.xunke.das.system.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.xunke.das.system.bean.User;
import com.xunke.das.system.service.UserService_bak;

/**
 *
 * @File name:  UserServlet.java
 * @Description:   
 * @Create on:  2018年8月17日 下午7:52:23
 * @LinkPage :  
 * @ChangeList
 * ---------------------------------------------------
 * Date         Editor              ChangeReasons
 *
 *
 */
@WebServlet("/userServlet")
public class UserServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 189906650295152382L;

	private UserService_bak userService=new UserService_bak();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		User user=new User();
//		user.setLoginName("admin2");
//		user.setUserName("admin2");
//		user.setPassword("123456");
//		try {
//			userService.insert(user);
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		try {
			User user=userService.getUser(2);
			System.out.println(user.toString());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
